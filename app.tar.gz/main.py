import flet as ft
from flet import (
    Page,
    Container,
    Column,
    Row,
    Text,
    TextField,
    ElevatedButton,
    IconButton,
    DataTable,
    DataColumn,
    DataRow,
    DataCell,
    Card,
    CircleAvatar,
    icons,
    colors,
    border_radius,
    padding,
    alignment,
)
import sqlite3
from datetime import datetime
from contextlib import contextmanager

class StudentDashboard:
    def __init__(self):
        self.db_path = 'students.db'
        self.init_db()
    
    @contextmanager
    def get_db_connection(self):
        conn = sqlite3.connect(self.db_path)
        try:
            yield conn
        finally:
            conn.close()
        
    def init_db(self):
        with self.get_db_connection() as conn:
            cursor = conn.cursor()
            cursor.execute('''
                CREATE TABLE IF NOT EXISTS students (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    nom TEXT,
                    prenom TEXT,
                    email TEXT,
                    classe TEXT,
                    date_inscription TEXT
                )
            ''')
            conn.commit()

    def main(self, page: Page):
        page.title = "Gestion des Étudiants"
        page.padding = 20
        page.bgcolor = colors.BLUE_GREY_50
        page.window_width = 1200
        page.window_height = 800
        
        # État des contrôles
        self.nom = TextField(label="Nom", width=200)
        self.prenom = TextField(label="Prénom", width=200)
        self.email = TextField(label="Email", width=200)
        self.classe = TextField(label="Classe", width=200)
        
        # DataTable pour afficher les étudiants
        self.students_table = DataTable(
            columns=[
                DataColumn(Text("ID")),
                DataColumn(Text("Nom")),
                DataColumn(Text("Prénom")),
                DataColumn(Text("Email")),
                DataColumn(Text("Classe")),
                DataColumn(Text("Date d'inscription")),
                DataColumn(Text("Actions")),
            ],
            rows=[],
        )

        # Statistiques
        self.total_students = Text("0", size=30, weight="bold")
        self.students_per_class = Text("", size=16)

        def add_student(e):
            if all([self.nom.value, self.prenom.value, self.email.value, self.classe.value]):
                with self.get_db_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute('''
                        INSERT INTO students (nom, prenom, email, classe, date_inscription)
                        VALUES (?, ?, ?, ?, ?)
                    ''', (
                        self.nom.value,
                        self.prenom.value,
                        self.email.value,
                        self.classe.value,
                        datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    ))
                    conn.commit()
                
                self.clear_fields()
                self.update_table()
                self.update_stats()
                page.update()

        def delete_student(student_id):
            def delete_handler(e):
                with self.get_db_connection() as conn:
                    cursor = conn.cursor()
                    cursor.execute("DELETE FROM students WHERE id = ?", (student_id,))
                    conn.commit()
                self.update_table()
                self.update_stats()
                page.update()
            return delete_handler

        # def update_stats(self):
        #     with self.get_db_connection() as conn:
        #         cursor = conn.cursor()
        #         # Total d'étudiants
        #         cursor.execute("SELECT COUNT(*) FROM students")
        #         total = cursor.fetchone()[0]
        #         self.total_students.value = str(total)

        #         # Étudiants par classe
        #         cursor.execute("""
        #             SELECT classe, COUNT(*) as count 
        #             FROM students 
        #             GROUP BY classe
        #         """)
        #         stats = cursor.fetchall()
        #         stats_text = "\n".join([f"{classe}: {count}" for classe, count in stats])
        #         self.students_per_class.value = stats_text
                
        def update_table(self):
            with self.get_db_connection() as conn:
                cursor = conn.cursor()
                cursor.execute("SELECT * FROM students")
                students = cursor.fetchall()
                
                self.students_table.rows.clear()
                for student in students:
                    self.students_table.rows.append(
                        DataRow(
                            cells=[
                                DataCell(Text(str(student[0]))),
                                DataCell(Text(student[1])),
                                DataCell(Text(student[2])),
                                DataCell(Text(student[3])),
                                DataCell(Text(student[4])),
                                DataCell(Text(student[5])),
                                DataCell(
                                    Row(
                                        controls=[
                                            IconButton(
                                                icon=icons.DELETE_OUTLINE,
                                                icon_color=colors.RED_400,
                                                tooltip="Supprimer",
                                                on_click=delete_student(student[0])
                                            ),
                                        ]
                                    )
                                ),
                            ]
                        )
                    )

        def clear_fields(self):
            self.nom.value = ""
            self.prenom.value = ""
            self.email.value = ""
            self.classe.value = ""
            
        # Layout principal
        page.add(
            Row(
                controls=[
                    # Panneau latéral gauche (Formulaire)
                    Card(
                        content=Container(
                            content=Column(
                                controls=[
                                    Text("Nouvel Étudiant", size=20, weight="bold", color=colors.BLUE_700),
                                    self.nom,
                                    self.prenom,
                                    self.email,
                                    self.classe,
                                    ElevatedButton(
                                        text="Ajouter",
                                        on_click=add_student,
                                        bgcolor=colors.BLUE_700,
                                        color=colors.WHITE,
                                        width=200,
                                    ),
                                ],
                                spacing=20,
                            ),
                            padding=padding.all(20),
                            bgcolor=colors.WHITE,
                        ),
                        width=300,
                    ),

                    # Section principale
                    Column(
                        controls=[
                            # Cartes de statistiques
                            Row(
                                controls=[
                                    Card(
                                        content=Container(
                                            content=Column(
                                                controls=[
                                                    Text("Total Étudiants", size=16, color=colors.BLUE_700),
                                                    self.total_students,
                                                ],
                                                horizontal_alignment="center",
                                            ),
                                            padding=20,
                                            bgcolor=colors.WHITE,
                                        ),
                                        width=200,
                                    ),
                                    Card(
                                        content=Container(
                                            content=Column(
                                                controls=[
                                                    Text("Étudiants par Classe", size=16, color=colors.BLUE_700),
                                                    self.students_per_class,
                                                ],
                                            ),
                                            padding=20,
                                            bgcolor=colors.WHITE,
                                        ),
                                        width=200,
                                    ),
                                ],
                                alignment="start",
                            ),

                            # Table des étudiants
                            Card(
                                content=Container(
                                    content=Column(
                                        controls=[
                                            Text("Liste des Étudiants", size=20, weight="bold", color=colors.BLUE_700),
                                            self.students_table,
                                        ],
                                    ),
                                    padding=20,
                                    bgcolor=colors.WHITE,
                                ),
                            ),
                        ],
                        spacing=20,
                        expand=True,
                    ),
                ],
                spacing=20,
                expand=True,
            )
        )

        def initialize():
            pass
            # self.update_table()
            # self.update_stats()
            
        # Initialisation
        initialize()

if __name__ == "__main__":
    app = StudentDashboard()
    ft.app(target=app.main, view=ft.WEB_BROWSER)